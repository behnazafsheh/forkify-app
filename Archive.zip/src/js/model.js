export const state = {
    recipe: {},
  };

  export const loadRecipe = async function (id) {
    try {
      const response = await fetch(`https://forkify-api.herokuapp.com/api/v2/recipes/${id}`);
      const data = await response.json();
      console.log(data);
  
      if (!response.ok) throw new Error(`${data.message} ${response.status}`);
  
      const recipe = data.data.recipe;
  
      state.recipe = {
        id: recipe.id,
        title: recipe.title,
        publisher: recipe.publisher,
        ingredients: recipe.ingredients,
        sourceUrl: recipe.source_url,
        image: recipe.image_url,
        servings: recipe.servings,
        cookingTime: recipe.cooking_time,
      };
  
      console.log(state.recipe);

    } catch (err) {
      alert(err);
    }
  };